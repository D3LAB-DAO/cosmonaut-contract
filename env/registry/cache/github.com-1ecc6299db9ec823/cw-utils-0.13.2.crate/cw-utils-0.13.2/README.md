# Utils: Common types / utilities for specs

This is a collection of common types shared among many specs.
For example `Expiration`, which is embedded in many places.

Types should only be added here after they are duplicated in
a second contract, not "because we might need it"
