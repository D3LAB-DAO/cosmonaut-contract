This crate contains the core Cranelift code generator. It translates code from an
intermediate representation into executable machine code.
