//! Encodes VEX instructions. These instructions are those added by the Advanced Vector Extensions
//! (AVX).
