pub trait MyTrait {}

dyn_clone::clone_trait_object!(MyTrait);

fn main() {}
