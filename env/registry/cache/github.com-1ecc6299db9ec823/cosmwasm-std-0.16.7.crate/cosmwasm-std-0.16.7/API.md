# Smart Contract API

**TODO** define all provided imports and all required exports.

Along with the expected contents of the data structures.
