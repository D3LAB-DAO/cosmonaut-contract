## Rust version compatibility

SNAFU is tested and compatible back to Rust 1.31, released on
2018-12-06. Compatibility is controlled by Cargo feature flags.
(There are currently no features that require Rust beyond 1.31,
and therefore no version-specific feature flags.)
