# `cargo-manifest` 

_This is a fork of [`cargo_toml`](https://crates.io/crates/cargo_toml) to fix some issues for `cargo-chef` in a timely manner. Planning to expand on it over time._
