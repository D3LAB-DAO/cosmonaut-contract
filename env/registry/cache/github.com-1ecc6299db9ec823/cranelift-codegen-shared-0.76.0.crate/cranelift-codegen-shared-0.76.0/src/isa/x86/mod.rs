//! Shared x86-specific definitions.

mod encoding_bits;
pub use encoding_bits::*;
