//! Shared ISA-specific definitions.

pub mod x86;
