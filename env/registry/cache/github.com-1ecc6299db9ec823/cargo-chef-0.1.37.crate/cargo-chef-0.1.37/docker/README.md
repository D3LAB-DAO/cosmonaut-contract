This directory contains a Dockerfile to build a `cargo-chef` image that can be used as
a base layer for `planner` and `builder` stages in your Dockerfiles.