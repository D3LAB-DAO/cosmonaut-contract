This directory contains two independent cargo worspaces, one which is a
traditional single-crate workspace and another which is a multi-crate workspace
(with only one crate, but what matters is the directory layout).

These are used to test where the persistence files end up when all is said and
done.
