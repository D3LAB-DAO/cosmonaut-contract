# Changelog
All notable changes to this library will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this library adheres to Rust's notion of
[Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [0.10.1] - 2021-08-11
### Added
- `ff::BatchInvert` extension trait, implemented for iterators over mutable field elements
  which allows those field elements to be inverted in a batch. This trait is behind the
  new `alloc` feature flag.
- `ff::BatchInverter` struct, which provides methods for non-allocating batch inversion of
  field elements contained within slices.

## [0.10.0] - 2021-06-01
### Added
- `ff::PrimeFieldBits: PrimeField` trait, behind a `bits` feature flag.

### Changed
- MSRV is now 1.51.0.
- Bumped `bitvec` to 0.22 to enable fixing a performance regression in `ff 0.9`.
  The `bitvec::view::BitView` re-export has been replaced by
  `bitvec::view::BitViewSized`.
- The `bitvec` dependency and its re-exports have been gated behind the `bits`
  feature flag.

### Removed
- `ff::PrimeField::{ReprBits, char_le_bits, to_le_bits}` (replaced by
  `ff::PrimeFieldBits` trait).

### Fixed
- `#[derive(PrimeField)]` now works on small moduli (that fit in a single `u64`
  limb).

## [0.9.0] - 2021-01-05
### Added
- Re-export of `bitvec::view::BitView`.
- `ff::FieldBits<V>` type alias for the return type of
  `ff::PrimeField::{char_le_bits, to_le_bits}`.

### Changed
- Bumped `bitvec` to 0.20, `rand_core` to 0.6.

### Removed
- `From<Self>` and `From<&Self>` bounds on `ff::PrimeField::Repr`.

## [0.8.0] - 2020-09-08
### Added
- `ff::PrimeField::{ReprBits, char_le_bits, to_le_bits}`, and a public
  dependency on `bitvec 0.18`.
- `ff::Field::cube` method with provided implementation.
- `Send + Sync` bounds on `ff::PrimeField::ReprBits`

### Changed
- MSRV is now 1.44.0.
- `ff::Field::random<R: RngCore + ?Sized>(rng: &mut R) -> Self` has been changed
  to `Field::random(rng: impl RngCore) -> Self`, to aligh with
  `group::Group::random`.

### Removed
- `fmt::Display` bound on `ff::Field`.
- `ff::PrimeField::char` (replaced by `ff::PrimeField::char_le_bits`).
- `ff::{BitIterator, Endianness, PrimeField::ReprEndianness` (replaced by
  `ff::PrimeField::to_le_bits`).
